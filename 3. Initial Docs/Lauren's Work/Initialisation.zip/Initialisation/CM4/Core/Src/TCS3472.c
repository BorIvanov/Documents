/*
 * TCS3472.c
 *
 *  Created on: 7 dec. 2022
 *      Author: laure
 */

#include "TCS3472.h"

void TCS3472_Init(const TCS3472* const self){

}

uint16_t TCS3472_ReceiveStatus(const TCS3472* const self){

}

void TCS3472_Transmit(const TCS3472* const self, uint8_t data_reg, uint8_t data_size, uint8_t pData, uint8_t pData_size){

}

TCS3472 TCS3472_Create(uint8_t addr, I2C_HandleTypeDef* inBus){

}

